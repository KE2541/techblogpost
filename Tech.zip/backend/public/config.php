<?php
error_reporting(0);
ini_set('display_errors', 0);

define('DB_HOST', 'sql209.infinityfree.com');
define('DB_USER', 'if0_42344574');
define('DB_PASS', 'Thurwa202612');
define('DB_NAME', 'if0_42344574_techblogs');

function getDB() {
  static $pdo = null;
  if ($pdo === null) {
    try {
      $pdo = @new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
      ]);
    } catch (PDOException $e) {
      return null;
    }
  }
  return $pdo;
}

function dbFallback() {
  http_response_code(503);
  echo json_encode(['error' => 'Database not configured. Run setup.php first.']);
  exit;
}
