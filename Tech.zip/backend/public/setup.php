<?php
error_reporting(0);
ini_set('display_errors', 0);
require_once __DIR__ . '/config.php';

$host = DB_HOST;
$user = DB_USER;
$pass = DB_PASS;
$dbName = DB_NAME;

try {
  $pdo = @new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
  ]);

  try {
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  } catch (PDOException $e) {
    // User may not have CREATE privilege; that's OK if DB already exists
  }
  try {
    $pdo->exec("USE `$dbName`");
  } catch (PDOException $e) {
    die("Cannot access database. Check your DB credentials.");
  }

  $pdo->exec("CREATE TABLE IF NOT EXISTS posts (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    content LONGTEXT,
    excerpt TEXT,
    category VARCHAR(100) DEFAULT 'AI',
    tags JSON DEFAULT '[]',
    cover_image VARCHAR(500) DEFAULT '',
    video_url VARCHAR(500) DEFAULT '',
    author VARCHAR(200) DEFAULT 'Admin',
    published TINYINT(1) DEFAULT 1,
    scheduled_at DATETIME DEFAULT NULL,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    rating DECIMAL(3,2) DEFAULT 0.00,
    rating_count INT DEFAULT 0,
    views INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $pdo->exec("CREATE TABLE IF NOT EXISTS comments (
    id VARCHAR(36) PRIMARY KEY,
    post_id VARCHAR(36) NOT NULL,
    name VARCHAR(200) DEFAULT 'Anonymous',
    email VARCHAR(200) DEFAULT '',
    content TEXT NOT NULL,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    emojis JSON DEFAULT '[]',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $pdo->exec("CREATE TABLE IF NOT EXISTS subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(200) NOT NULL UNIQUE,
    subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    active TINYINT(1) DEFAULT 1
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $pdo->exec("CREATE TABLE IF NOT EXISTS ads_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slot_name VARCHAR(100) NOT NULL UNIQUE,
    code TEXT,
    active TINYINT(1) DEFAULT 0
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $pdo->exec("INSERT IGNORE INTO ads_config (slot_name) VALUES
    ('header'), ('sidebar'), ('inline'), ('footer'), ('popup')");

  $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    token VARCHAR(36) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $hash = password_hash('Thurw@202612', PASSWORD_DEFAULT);
  $pdo->prepare("INSERT IGNORE INTO admins (username, password_hash) VALUES (?, ?)")
      ->execute(['KE2541', $hash]);

  echo "Database setup complete! All tables created.\n";
  echo "<br><a href='index.html'>Go to Homepage</a>\n";
} catch (PDOException $e) {
  die("Setup failed. Check your DB credentials and ensure the MySQL server is running.");
}
